function serial_codes = Load_MotoTrak_Serial_Codes(ver)

%LOAD_MOTOTRAK_SERIAL_CODES.m
%
%	Vulintus, Inc.
%
%	MotoTrak serial communication code library.
%
%	Library V2 documentation:
%	https://docs.google.com/spreadsheets/d/e/2PACX-1vReo5eWk6dJPhLLSyOjzEkLDV0jcmT-TpUhvU49oHJ0S6veWHT8HyJVZmaRD_IX6uC9FPhcvgqdY_mW/pubhtml
%
%	This file was programmatically generated: 02-May-2018 12:58:50
%

serial_codes = [];

switch ver

	case 2.00
		serial_codes.CUR_DEF_VERSION = 200;

		serial_codes.SKETCH_VERIFY = 65;
		serial_codes.GET_SKETCH_VERSION = 90;
		serial_codes.GET_SERIAL_LIB_VER = 91;
		serial_codes.GET_BOOTH_NUMBER = 66;
		serial_codes.DEVICE_ID = 68;

		serial_codes.READ_DEVICE_VAL = 77;
		serial_codes.RESET_COUNTER = 76;
		serial_codes.STREAM_ENABLE = 103;
		serial_codes.SET_STREAM_ORDER = 97;
		serial_codes.RETURN_STREAM_ORDER = 100;
		serial_codes.SET_STREAM_PERIOD = 101;
		serial_codes.RETURN_STREAM_PERIOD = 102;
		serial_codes.SET_EVENT_INPUT = 105;
		serial_codes.RETURN_EVENT_INPUT = 106;
		serial_codes.SET_EVENT_SIZE = 107;
		serial_codes.RETURN_EVENT_SIZE = 108;

		serial_codes.SAVE_1BYTE_EEPROM = 69;
		serial_codes.READ_1BYTE_EEPROM = 70;
		serial_codes.SAVE_2BYTES_EEPROM = 67;
		serial_codes.READ_2BYTES_EEPROM = 73;
		serial_codes.SAVE_4BYTES_EEPROM = 71;
		serial_codes.READ_4BYTES_EEPROM = 72;

		serial_codes.TRIGGER_FEEDER = 87;
		serial_codes.STOP_FEED = 86;
		serial_codes.SET_FEED_TRIG_DUR = 53;
		serial_codes.RETURN_FEED_TRIG_DUR = 52;

		serial_codes.SET_AP_DIST = 110;
		serial_codes.RETURN_AP_DIST = 111;

		serial_codes.PLAY_TONE = 49;
		serial_codes.STOP_TONE = 50;
		serial_codes.SET_TONE_INDEX = 41;
		serial_codes.RETURN_TONE_INDEX = 42;
		serial_codes.SET_TONE_FREQ = 43;
		serial_codes.RETURN_TONE_FREQ = 44;
		serial_codes.SET_TONE_DUR = 45;
		serial_codes.RETURN_TONE_DUR = 46;
		serial_codes.SET_TONE_TYPE = 47;
		serial_codes.RETURN_TONE_TYPE = 48;
		serial_codes.SET_TONE_MON = 37;
		serial_codes.RETURN_TONE_MON = 38;
		serial_codes.SET_TONE_THRESH = 39;
		serial_codes.RETURN_TONE_THRESH = 40;
		serial_codes.RETURN_MAX_TONES = 51;

		serial_codes.SEND_TRIGGER = 88;
		serial_codes.STOP_TRIGGER = 104;
		serial_codes.SET_TRIG_INDEX = 78;
		serial_codes.RETURN_TRIG_INDEX = 79;
		serial_codes.SET_TRIG_DUR = 56;
		serial_codes.RETURN_TRIG_DUR = 55;
		serial_codes.SET_TRIG_TYPE = 80;
		serial_codes.RETURN_TRIG_TYPE = 81;
		serial_codes.SET_TRIG_MON = 82;
		serial_codes.RETURN_TRIG_MON = 83;
		serial_codes.SET_TRIG_THRESH = 84;
		serial_codes.RETURN_TRIG_THRESH = 85;

		serial_codes.SET_CAGE_LIGHTS = 57;
		serial_codes.RETURN_CAGE_LIGHTS = 58;
		serial_codes.CMD_SET_EEPROM_ADDR = 1;
		serial_codes.CMD_WRITE_EEPROM = 2;
		serial_codes.CMD_READ_EEPROM = 3;
		serial_codes.CMD_DEVICE_READING = 4;
		serial_codes.CMD_STREAM_ENABLE = 5;
		serial_codes.CMD_SET_STREAM_ORDER = 6;
		serial_codes.CMD_SET_STREAM_PERIOD = 7;
		serial_codes.CMD_SET_EVENT_INPUT = 8;
		serial_codes.CMD_SET_EVENT_SIZE = 9;
		serial_codes.CMD_SET_FEED_TRIG_DUR = 10;
		serial_codes.CMD_SET_TONE_INDEX = 11;
		serial_codes.CMD_SET_TONE_FREQ = 12;
		serial_codes.CMD_SET_TONE_DUR = 13;
		serial_codes.CMD_SET_TONE_TYPE = 14;
		serial_codes.CMD_SET_TONE_MON = 15;
		serial_codes.CMD_SET_TONE_THRESH = 16;
		serial_codes.CMD_PLAY_TONE = 17;
		serial_codes.CMD_SEND_TRIGGER = 18;
		serial_codes.CMD_SET_TRIG_INDEX = 19;
		serial_codes.CMD_SET_TRIG_DUR = 20;
		serial_codes.CMD_SET_TRIG_TYPE = 21;
		serial_codes.CMD_SET_TRIG_MON = 22;
		serial_codes.CMD_SET_TRIG_THRESH = 23;
		serial_codes.CMD_READ_AP_DIST = 24;
		serial_codes.CMD_SEND_AP_COMM = 25;
		serial_codes.CMD_SET_CAGE_LIGHTS = 26;
		serial_codes.EEPROM_BOOTH_NUM = 0;

		serial_codes.EEPROM_CAL_BASE_INT = 4;

		serial_codes.EEPROM_CAL_FORCE_INT = 6;

		serial_codes.EEPROM_CAL_TICK_INT = 8;

		serial_codes.EEPROM_SN = 10;

		serial_codes.EEPROM_BOOTH_ID = 14;

		serial_codes.EEPROM_CAL_BASE_FL = 38;

		serial_codes.EEPROM_CAL_SLOPE_FL = 42;

end
